import {
  MatDivider,
  MatDividerModule
} from "./chunk-JTIM4MYN.js";
import "./chunk-KAPXTIMC.js";
import "./chunk-6AAPOV4L.js";
import "./chunk-FXMAG7HE.js";
import "./chunk-PJCOEOR6.js";
import "./chunk-ZH6LALFQ.js";
import "./chunk-WDOPGFCJ.js";
import "./chunk-WDMUDEB6.js";
export {
  MatDivider,
  MatDividerModule
};
