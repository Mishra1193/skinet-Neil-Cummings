import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Pagination } from '../../shared/models/pagination';
import { Product } from '../../shared/models/product';

@Injectable({
  providedIn: 'root',
})
export class ShopService {
  baseUrl = 'http://localhost:5000/api/';
  private http = inject(HttpClient);
  brands: string[] = [];
  types: string[] = [];

  getProducts(brands?: string[], types?: string[]) {
    let params = new HttpParams();

    if (brands?.length) {
      params = params.set('brands', brands.join(',')); // use set to avoid duplicates
    }

    if (types?.length) {
      params = params.set('types', types.join(','));
    }

    params = params.set('pageSize', 20);

    return this.http.get<Pagination<Product>>(this.baseUrl + 'products', {
      params,
    });
  }

  // getBrands()
  getBrands() {
    if (this.brands.length > 0) return;
    return this.http
      .get<string[]>(this.baseUrl + 'products/brands')
      .subscribe({ next: (r) => (this.brands = r) });
  }

  // getTypes()
  getTypes() {
    if (this.types.length > 0) return;
    return this.http
      .get<string[]>(this.baseUrl + 'products/types')
      .subscribe({ next: (r) => (this.types = r) });
  }
}
