import { Component, inject, OnInit } from '@angular/core';
import { ShopService } from '../../../core/services/shop.service';
import { Product } from '../../../shared/models/product';
import { ProductItemComponent } from './product-item/product-item.component';
import { MatDialog } from '@angular/material/dialog';
import { FiltersDialogComponent } from '../../../features/shop/filters-dialog/filters-dialog.component';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';

@Component({
  selector: 'app-shop',
  imports: [
    ProductItemComponent,
    MatButton,
    MatIcon
  ],
  templateUrl: './shop.component.html',
  styleUrl: './shop.component.scss',
})
export class ShopComponent implements OnInit {
  products: Product[] = [];
  private shopService = inject(ShopService);
  private dialogService = inject(MatDialog);
  selectedBrands: string[] = [];
  selectedTypes: string[] = [];
  selectedSort: string = 'name';
  sortOption = [
    {
      name: 'Alphabetical',
      value: 'name',
    },
    {
      name: 'Price Low-High',
      value: 'PriceAsc',
    },
    {
      name: 'Price High-Low',
      value: 'PriceDesc',
    },
  ];

  ngOnInit(): void {
    this.shopService.getBrands();
    this.shopService.getTypes();
  }

  getProducts() {
    this.shopService.getProducts(this.selectedBrands, this.selectedTypes).subscribe({
      next: (response) => (this.products = response.data),
      error: (error) => console.log(error),
    });
  }

  openFiltersDialog() {
    const dialogRef = this.dialogService.open(FiltersDialogComponent, {
      minWidth: '500px',
      data: {
        selectedBrands: this.selectedBrands,
        selectedTypes: this.selectedTypes,
      },
    });

    dialogRef.afterClosed().subscribe({
      next: (result?: {
        selectedBrands: string[];
        selectedTypes: string[];
      }) => {
        if (!result) return;
        this.selectedBrands = result.selectedBrands ?? [];
        this.selectedTypes = result.selectedTypes ?? [];
        this.shopService
          .getProducts(this.selectedBrands, this.selectedTypes)
          .subscribe({
            next: (r) => (this.products = r.data),
            error: (e) => console.log(e),
          });
      },
    });
  }
}
